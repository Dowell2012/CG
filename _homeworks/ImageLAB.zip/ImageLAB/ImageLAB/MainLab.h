#include "ConfigCV.h"

// definitions of all the test modules
void ThreshDemo(const cv::Mat& img);